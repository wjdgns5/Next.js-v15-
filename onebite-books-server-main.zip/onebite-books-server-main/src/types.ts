export type Category = 'FE' | 'BE';
